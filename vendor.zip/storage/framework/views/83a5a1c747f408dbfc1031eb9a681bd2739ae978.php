<?php $__env->startSection('container'); ?>
<div class="container">
    <h1>Selamat Datang di Sistem Informasi Kosan</h1>
    <p>Silakan navigasi menggunakan menu di sidebar.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem informasi kost\sikoster\resources\views/admin/beranda.blade.php ENDPATH**/ ?>