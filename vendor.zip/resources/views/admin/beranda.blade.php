@extends('admin.layouts.main')

@section('container')
<div class="container">
    <h1>Selamat Datang di Sistem Informasi Kosan</h1>
    <p>Silakan navigasi menggunakan menu di sidebar.</p>
</div>
@endsection
