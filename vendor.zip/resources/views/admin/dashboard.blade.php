@extends('admin.layouts.main')

@section('container')
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-6 mb-4">
            <h1 class="m-0">Dashboard</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-3 col-6">
            <div class="card bg-info mb-3 text-white">
                <div class="card-header">
                    <h3>{{ $totalKamar }}</h3>
                    <p>Total Kamar</p>
                </div>
                <a href="/admin/kamar" class="card-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-lg-3 col-6">
            <div class="card bg-success mb-3 text-white">
                <div class="card-header">
                    <h3>{{ $kamarKosong }}</h3>
                    <p>Kamar Kosong</p>
                </div>
                <a href="/admin/kamar" class="card-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-lg-3 col-6">
            <div class="card bg-warning mb-3 text-white">
                <div class="card-header">
                    <h3>{{ $kamarTerisi }}</h3>
                    <p>Kamar Terisi</p>
                </div>
                <a href="/admin/kamar" class="card-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-lg-3 col-6">
            <div class="card bg-danger mb-3 text-white">
                <div class="card-header">
                    <h3>{{ $totalPenghuni }}</h3>
                    <p>Total Penghuni</p>
                </div>
                <a href="/admin/penghuni" class="card-footer text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>

    <div class="row mt-3">
        <h4>Pembayaran Terbaru</h4>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Penghuni</th>
                    <th>Jumlah</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pembayaranTerbaru as $pembayaran)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $pembayaran->user->name ?? '-' }}</td>
                    <td>Rp {{ number_format($pembayaran->jumlah, 0, ',', '.') }}</td>
                    <td>{{ $pembayaran->status }}</td>
                    <td>{{ $pembayaran->created_at->format('d M Y') }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
